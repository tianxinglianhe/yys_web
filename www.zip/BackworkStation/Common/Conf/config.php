<?php
return array(
	#'配置项'=>'配置值'
	#本地数据库设置
//	'DB_TYPE' => 'mysql', #数据库类型
//	'DB_HOST' => 'localhost', #服务器地址
//	'DB_NAME' => 'yiyousu', #数据库名
//	'DB_USER' => 'root', #用户名
//	'DB_PWD' => '', #密码
//	'DB_PORT' => '3306', #端口
//	'DB_PREFIX' => '', #数据库表前缀

	#RDS设置
	'DB_TYPE' => 'mysql', #数据库类型
	'DB_HOST' => 'rm-2zes5472l097ri5fc.mysql.rds.aliyuncs.com', #服务器地址
	'DB_NAME' => 'yiyousu', #数据库名
	'DB_USER' => 'yys_web', #用户名
	'DB_PWD' => 'YIYOUSUmysql1123', #密码
	'DB_PORT' => '3306', #端口
	'DB_PREFIX' => '', #数据库表前缀

	#虚拟主机
//	'DB_TYPE' => 'mysql', #数据库类型
//	'DB_HOST' => 'qdm163237595.my3w.com', #服务器地址
//	'DB_NAME' => 'qdm163237595_db', #数据库名
//	'DB_USER' => 'qdm163237595', #用户名
//	'DB_PWD' => 'mysqlmysql', #密码
//	'DB_PORT' => '3306', #端口
//	'DB_PREFIX' => '', #数据库表前缀

	#BeeCloud
	'bcAppId' => 'e4f91bf2-8a3c-4c2e-9b12-10a60d23c7ad',#BeeCloud APP_ID
	'bcAppSecret' => 'f8cebaef-9749-4bed-921f-1d020cec14dc',#BeeCloud APP_SECRET
	'bcWxChannel' => 'WX_NATIVE',#BeeCloud Wechat CHANNEL

	#UCloud
	'ucPublicKey' => 'WLw4pYG8jP3ECIQs8TRlffSQdykzUMojKGt6vENIkDPyuFio4+Z55A==',
	'ucPrivateKey' => '2ee9865d56c51fe23890983e69811e3139c73029',

	#Company
	'company_bank_public_no' => '1109 1017 0510 601',
	'company_name' => '天行联合（北京）国际品牌管理顾问有限公司',
	'company_zhaoshang_bank_no' => '6214 8501 0796 6498',
	'company_zhaoshang_bank_name' => '招商银行玉泉路支行',
	'company_zhaoshang_bank_owner_name' => '卢志浩',
	'company_gong_bank_no' => '6222 0002 0011 6161 092',
	'company_gong_bank_name' => '工商银行翠微路公主坟支行',
	'company_gong_bank_owner_name' => '卢志浩',
	'company_online_market_url' => 'www.yiyousu.com',
	'company_after_sale_tel_no' => '18510780526',
	'company_quality_tel_no' => '13811188441',
	'company_addr' => '北京市石景山区京原路19号院4号楼  18510780526/010-88692908',
	'remark' => '白色：留存  粉色：司机  蓝色：客户  黄色：财务',
	'name' => '',
	'area_principal' => '卢志浩13811188441',
	'out_storeroom' => '',
	'driver'=>'',
	'consignee'=>'',

);