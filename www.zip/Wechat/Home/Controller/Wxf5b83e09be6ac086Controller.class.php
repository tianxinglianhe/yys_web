<?php
namespace Home\Controller;

use Think\Controller;

class Wxf5b83e09be6ac086Controller extends Controller
{
	public function openCallback(){

	}
}